import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../core/constants/strings.dart';
import '../models/ecard.dart';
import '../models/ecard_guest.dart';
import '../models/ecard_template.dart';
import '../models/user_profile.dart';
import 'auth_provider.dart';

// Mirrors event_provider.dart's pattern exactly: thin StreamProvider
// wrappers around firestoreServiceProvider, nothing else. No new
// FirestoreService instance, no new auth mechanism — reuses the
// providers already declared in auth_provider.dart.

final ecardsForOrganizerProvider =
    StreamProvider.family<List<Ecard>, String>((ref, organizerId) {
  return ref.watch(firestoreServiceProvider).watchEcardsForOrganizer(organizerId);
});

final ecardByIdProvider = StreamProvider.family<Ecard?, String>((ref, id) {
  return ref.watch(firestoreServiceProvider).watchEcard(id);
});

/// Takes (eventId, organizerId) — see watchEcardForEvent's doc comment
/// for why organizerId has to be passed through to the query itself,
/// not just checked after the fact.
final ecardForEventProvider = StreamProvider.family<Ecard?, (String eventId, String organizerId)>((ref, args) {
  return ref.watch(firestoreServiceProvider).watchEcardForEvent(args.$1, args.$2);
});

final ecardTemplatesProvider =
    StreamProvider.family<List<EcardTemplate>, EcardOccasion?>((ref, occasion) {
  return ref.watch(firestoreServiceProvider).watchEcardTemplates(occasion: occasion);
});

final guestsForEcardProvider =
    StreamProvider.family<List<EcardGuest>, String>((ref, ecardId) {
  return ref.watch(firestoreServiceProvider).watchGuestsForEcard(ecardId);
});

/// Keyed by a (ecardId, guestId) record — Phase 6's guest card/QR view
/// needs one specific guest, not the whole list.
final ecardGuestProvider =
    StreamProvider.family<EcardGuest?, (String ecardId, String guestId)>((ref, ids) {
  return ref.watch(firestoreServiceProvider).watchEcardGuest(ids.$1, ids.$2);
});

/// Public E-Cards page (/e-cards/public) — no organizer scoping.
final publicEcardsProvider = StreamProvider<List<Ecard>>((ref) {
  return ref.watch(firestoreServiceProvider).watchPublicEcards();
});

/// Admin moderation view — every E-Card regardless of owner.
final allEcardsForAdminProvider = StreamProvider<List<Ecard>>((ref) {
  return ref.watch(firestoreServiceProvider).watchAllEcardsForAdmin();
});

/// Admin user directory — every registered account.
final allUsersForAdminProvider = StreamProvider<List<UserProfile>>((ref) {
  return ref.watch(firestoreServiceProvider).watchAllUsersForAdmin();
});
